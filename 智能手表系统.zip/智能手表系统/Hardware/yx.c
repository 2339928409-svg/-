#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"
#include "anjian.h"
#include "fmq.h"
#include "dsq.h" 
#include "OLED_Data.h"
#include "wifi.h"
#include "UART.h"

#define uchar unsigned char

extern volatile uint8_t rx_complete_flag;
extern volatile char esp_rx_buf[256];
extern volatile uint8_t esp_rx_index;
char wl=0;
uint8_t i = 0,aj=0,aj_a=0,aj_b=0,aj_c=0,tim2_i=0,xx=0;
uchar q=1;
uchar sjx[10]={2,1,0,1,2,0,3,1,0,3};
uchar sjy[10]={3,2,0,3,0,2,1,0,2,0};
//extern uint8_t i;

int shezhi(){
	aj=0;
uint8_t  gb = 0;	
	
OLED_Clear();	
OLED_ShowChinese(0,0, "开热点");
OLED_ShowChinese(0,16, "连热点");
OLED_ReverseArea(0, gb*16, 128, 16);
	
while(1){
	
OLED_Update();

	
			switch(aj){
				case 1: aj=0;if(gb>0){OLED_ReverseArea(0, gb*16, 128, 16);gb--;OLED_ReverseArea(0, gb*16, 128, 16);}; break;
				//case 2: ;break;
				case 3: 
								aj=0;
								OLED_ShowChinese(64,gb*16, "执行中");
								OLED_ReverseArea(64, gb*16, 48, 16);
								OLED_Update();
								if(gb==0){wifi_kai();OLED_ShowChinese(64,gb*16, "成功了");wl=1;}
								if(gb==1){wifi_lian();OLED_ShowChinese(64,gb*16, "成功了");wl=2;}
								OLED_ReverseArea(64, gb*16, 48, 16);
								OLED_Update();
									break;
									
				case 5:aj=0; return 0;break;
				case 6:aj=0; if(gb<3){OLED_ReverseArea(0, gb*16, 128, 16);gb++;OLED_ReverseArea(0, gb*16, 128, 16);}break;
				//case 1: ; break;
				default: aj=0;break;
			}
	
}
	
}
//聊天室
int lts(){
	aj=0;
uint8_t  gb = 0,b=0;//b冒号标志位	
char xx[256]={0};
OLED_Clear();	

if(wl==0){OLED_ShowChinese(0,0, "热点未连接");OLED_Update();while(aj==0);return 0;}

	
while(1){
	
OLED_Update();

	
	//处理串口接收
	if(rx_complete_flag==1){
	
		for( char i=0,j=0;i<255;i++){//清除后缀,对消息显存赋值
					if(esp_rx_buf[i]=='\n'||esp_rx_buf[i]=='\r'){esp_rx_buf[i]='\0';break;}
					if(b==1){xx[j]=esp_rx_buf[i];j++;}
					if(esp_rx_buf[i]==':'){b=1;}
				}
		b=0;
	OLED_ClearArea(0,0,128,16);
	OLED_ShowString(0, 0,(char*)xx, OLED_8X16);
	OLED_Update();
	rx_complete_flag=0;
	}
	
	if(wl==1){
				switch(aj){
				//case 1: if(gb>0){OLED_ReverseArea(0, gb*16, 128, 16);gb--;OLED_ReverseArea(0, gb*16, 128, 16);}; break;
				//case 2: ;break;
				case 3: 
								aj=0;
								OLED_ClearArea(0,0,128,16);
								wifi_kai_fs("krd123");
								OLED_ShowString(0, 0,"krd123", OLED_8X16);

								OLED_Update();
									break;
									
				case 5:aj=0;return 0;break;
				//case 6:; if(gb<3){OLED_ReverseArea(0, gb*16, 128, 16);gb++;OLED_ReverseArea(0, gb*16, 128, 16);}break;
				//case 1: ; break;
				default: aj=0;break;
			}
	}
	else if(wl==2){
					switch(aj){
				//case 1: if(gb>0){OLED_ReverseArea(0, gb*16, 128, 16);gb--;OLED_ReverseArea(0, gb*16, 128, 16);}; break;
				//case 2: ;break;
				case 3: 
								aj=0;
								OLED_ClearArea(0,0,128,16);
								wifi_lian_fs("lrd456");
								OLED_ShowString(0, 0,"lrd456", OLED_8X16);

								OLED_Update();
									break;
									
				case 5:aj=0;; return 0;break;
			//	case 6:; if(gb<3){OLED_ReverseArea(0, gb*16, 128, 16);gb++;OLED_ReverseArea(0, gb*16, 128, 16);}break;
				//case 1: ; break;
				default: aj=0;break;
			}
	}

	
}

}
int sjhs(void)
{
 aj=0;
    uint8_t  j = 0,q=0,f=0,zd=20;
	
   // fmq_Init();
		//fmq_set1();
	
    OLED_Init();
   
	
	
		OLED_Clear();	
	
		OLED_ShowImage(0, 0,128, 64, sjyx);
			
    OLED_Update(); 
		Delay_s(3);
	while(1){
		
	

			switch(aj){
				case 1:aj=0;if(q>0){q--;} ; break;
				case 2:aj=0;f=0;zd=20; break;
				case 3:aj=0;if(zd>0){zd--;OLED_DrawLine(87, q*16+4,0, q*16+4);
									if(sjy[i]==q){f++;};} ; break;
				case 5:aj=0;OLED_Clear();OLED_Update();return 0; break;
				case 6:aj=0;if(q<3){q++;}  ; break;
				//case 1: ; break;
				default:aj=0; break;
			}

				OLED_ShowChinese(111,0, "分");
				OLED_ShowNum(111, 16, f, 2, OLED_8X16);

				OLED_ShowChinese(111,32, "弹");
				OLED_ShowNum(111, 48,zd, 2, OLED_8X16);

				OLED_ShowImage(87, q*16, 24, 16, qiang);
				OLED_ShowImage(sjx[i]*16, sjy[i]*16, 16, 16, fk);
	
		OLED_Update(); 
		
		OLED_Clear();
	}
  
    
}

int kon() {
	aj=0;
   
    OLED_Clear();
    OLED_ShowChinese(28, 26, "空程序");
    OLED_Update(); 
    while(1) {
        
        
        if(aj == 5) {   
            break;
        }     
    }
    OLED_Clear();
    OLED_Update();
    return 0;
}
	
	
	int szq(){
		aj=0;
	uint8_t qp[3][3]={0};
	char zb[2]={'0','0'};
	
	uint8_t x1=0,y1=0,x=0,y=0,qi=0,i=0,j=0,pj=0,msi=0,ms=0,kzq=1,zdpp=0;
	
	/*OLED初始化*/
//	OLED_Init();
//	anjian_Init();
OLED_Clear();	
OLED_ShowChinese(0,0, "单机");
OLED_ShowChinese(0,16, "联机");
OLED_ReverseArea(0, msi*16, 128, 16);
	
	
	while(1){//二级菜单
		if(ms!=0){break;}
		OLED_Update();
	
	
			switch(aj){
				case 1: aj=0;if(msi>0){OLED_ReverseArea(0, msi*16, 128, 16);msi--;OLED_ReverseArea(0, msi*16, 128, 16);}; break;
				//case 2: ;break;
				case 3: 
					aj=0;
								if(msi==0){ms=1;}
								if(msi==1){ms=2;}
								break;
									
				case 5:aj=0; return 0;break;
				case 6:aj=0; if(msi<3){OLED_ReverseArea(0, msi*16, 128, 16);msi++;OLED_ReverseArea(0, msi*16, 128, 16);}break;
				//case 1: ; break;
				default: aj=0;break;
			}
	
	}
if(ms==1){
	OLED_Clear();
	OLED_ShowImage(0, 0, 64, 64, qipan);
	

	OLED_ShowImage(5, 5, 5, 5,gb);

	 OLED_Update();
	
	while(1){
		
		
		
			switch(aj){//1246光标移动，3下棋，5退出
				case 1: aj=0;if(y1>6){y-=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage(x1+5, (y1-=23)+5, 5, 5,gb);}; break;
				case 2: aj=0;if(x1<30){x+=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage((x1+=23)+5, y1+5, 5, 5,gb);}; break;
				
				case 3: aj=0;if(qp[y][x]==0){pj++;if(pj>8){OLED_ShowChinese(80,24, "平局");}//
									if(qi==0){qi=1;qp[y][x]=1;OLED_ShowImage(x1, y1, 15, 15, fang);}
										else{qi=0;qp[y][x]=2;OLED_ShowImage(x1, y1, 15, 15, sanjiao);}}; break;
				
				case 4: aj=0;if(x1>6){x-=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage((x1-=23)+5, y1+5, 5, 5,gb);}; break;
				case 5: aj=0;OLED_Clear();OLED_Update();return 0; break;
				case 6: aj=0;if(y1<30){y+=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage(x1+5, (y1+=23)+5, 5, 5,gb);}; break;
				default: aj=0;break;
			}
		if ((qp[0][0] == qp[0][1]) && (qp[0][1] == qp[0][2])) {	
			if(qp[0][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[1][0] == qp[1][1]) && (qp[1][1] == qp[1][2])) {
			if(qp[1][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[1][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[2][0] == qp[2][1]) && (qp[2][1] == qp[2][2])) {
			if(qp[2][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[2][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[0][0] == qp[1][0]) && (qp[1][0] == qp[2][0])) {
			if(qp[0][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[0][1] == qp[1][1]) && (qp[1][1] == qp[2][1])) {
			if(qp[0][1] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][1] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[0][2] == qp[1][2]) && (qp[1][2] == qp[2][2])) {
			if(qp[0][2] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][2] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
					
    if ((qp[0][0] == qp[1][1]) && (qp[1][1] == qp[2][2])) {
			if(qp[0][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
					
    if ((qp[0][2] == qp[1][1]) && (qp[1][1] == qp[2][0])) {
			if(qp[0][2] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][2] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
					
			OLED_Update();
		
	}
return 0;
	}

	
	
	if(ms==2){
	OLED_Clear();	
	if(wl==0){OLED_ShowChinese(0,0, "热点未连接");OLED_Update();while(aj==0);return 0;}
	
	OLED_ShowImage(0, 0, 64, 64, qipan);
	

	OLED_ShowImage(5, 5, 5, 5,gb);

	 OLED_Update();

	while(1){
			//处理串口接收
	if(1&&rx_complete_flag==1){
	char b=0;
		for( char i=0;i<255;i++){//获得xy坐标
	
					if(b==1){zb[0]=esp_rx_buf[i]-'0';zb[1]=esp_rx_buf[i+1]-'0';break;}
					if(esp_rx_buf[i]==':'){b=1;}
				}
		if(b==1){
		if(kzq==1){kzq=2;}else{kzq=1;}//变更控制权
	pj++;if(pj>8){OLED_ShowChinese(80,24, "平局");}
					if(qi==0){qi=1;qp[zb[1]][zb[0]]=1;OLED_ShowImage(zb[0]*23, zb[1]*23, 15, 15, fang);}
						else{qi=0;qp[zb[1]][zb[0]]=2;OLED_ShowImage(zb[0]*23, zb[1]*23, 15, 15, sanjiao);};
						}

	OLED_Update();
	
	rx_complete_flag=0;
	}

	
		
		
			switch(aj){//1246光标移动，3下棋，5退出
				case 1: aj=0;if(y1>6){y-=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage(x1+5, (y1-=23)+5, 5, 5,gb);}; break;
				case 2: aj=0;if(x1<30){x+=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage((x1+=23)+5, y1+5, 5, 5,gb);}; break;
				
				case 3:
					aj=0;
								if(wl!=kzq){break;}



								if(qp[y][x]==0){pj++;if(pj>8){OLED_ShowChinese(80,24, "平局");}//
									if(qi==0){qi=1;qp[y][x]=1;OLED_ShowImage(x1, y1, 15, 15, fang);}
										else{qi=0;qp[y][x]=2;OLED_ShowImage(x1, y1, 15, 15, sanjiao);}};
										if(kzq==1){kzq=2;}else{kzq=1;}//变更控制权
										
										zb[0]=x+'0';
										zb[1]=y+'0';
							if(wl==1){wifi_kai_fs((char*)zb);}
							if(wl==2){wifi_lian_fs((char*)zb);}
										break;
				
				case 4: aj=0;if(x1>6){x-=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage((x1-=23)+5, y1+5, 5, 5,gb);}; break;
				case 5: aj=0;OLED_Clear();OLED_Update();return 0; break;
				case 6: aj=0;if(y1<30){y+=1;OLED_ClearArea(x1+5, y1+5, 5, 5);OLED_ShowImage(x1+5, (y1+=23)+5, 5, 5,gb);}; break;
				default: aj=0;break;
			}
		if ((qp[0][0] == qp[0][1]) && (qp[0][1] == qp[0][2])) {	
			if(qp[0][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[1][0] == qp[1][1]) && (qp[1][1] == qp[1][2])) {
			if(qp[1][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[1][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[2][0] == qp[2][1]) && (qp[2][1] == qp[2][2])) {
			if(qp[2][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[2][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[0][0] == qp[1][0]) && (qp[1][0] == qp[2][0])) {
			if(qp[0][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[0][1] == qp[1][1]) && (qp[1][1] == qp[2][1])) {
			if(qp[0][1] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][1] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
		
    if ((qp[0][2] == qp[1][2]) && (qp[1][2] == qp[2][2])) {
			if(qp[0][2] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][2] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
					
    if ((qp[0][0] == qp[1][1]) && (qp[1][1] == qp[2][2])) {
			if(qp[0][0] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][0] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
					
    if ((qp[0][2] == qp[1][1]) && (qp[1][1] == qp[2][0])) {
			if(qp[0][2] ==1){OLED_ShowImage(80,0, 15, 15, fang);OLED_ShowChinese(80,24, "胜利");}
				else if(qp[0][2] ==2){OLED_ShowImage(80,0, 15, 15, sanjiao);OLED_ShowChinese(80,24, "胜利");};}
					
			OLED_Update();
					}
return 0;
	}
	}


	
		

	
int hrd(){//数字华容道，
	aj=0;
	char a1[9]={' '-48,8,4,2,5,7,6,1,3};
	uchar i=0,j=0,x=0;//x为0所在位置
	
	OLED_Clear();
	OLED_ShowImage(0, 0, 64, 64, qipan);
	for(i=0;i<9;i++){//地图显示
		if(i<3){OLED_ShowChar(i*24, 0, a1[i]+48,OLED_8X16);}//第一行显示
		if(i>2&&i<6){OLED_ShowChar((i-3)*24, 24, a1[i]+48,OLED_8X16);}//第二行显示
		if(i>5){OLED_ShowChar((i-6)*24, 48, a1[i]+48,OLED_8X16);}//第3行显示
	}
	while(1){
		OLED_Update();

		
		
			switch(aj){
				case 1:aj=0; if(x-3>-1){a1[x]=a1[x-3];a1[x-3]=' '-48;x=x-3;
					for(i=0;i<9;i++){//地图显示
								if(i<3){OLED_ShowChar(i*24, 0, a1[i]+48,OLED_8X16);}//第一行显示
		if(i>2&&i<6){OLED_ShowChar((i-3)*24, 24, a1[i]+48,OLED_8X16);}//第二行显示
		if(i>5){OLED_ShowChar((i-6)*24, 48, a1[i]+48,OLED_8X16);}//第3行显示
	}}; break;//
				
				case 2: aj=0;if(x!=2&&x!=5&&x!=8){a1[x]=a1[x+1];a1[x+1]=' '-48;x=x+1;                
					for(i=0;i<9;i++){//地图显示
								if(i<3){OLED_ShowChar(i*24, 0, a1[i]+48,OLED_8X16);}//第一行显示
		if(i>2&&i<6){OLED_ShowChar((i-3)*24, 24, a1[i]+48,OLED_8X16);}//第二行显示
		if(i>5){OLED_ShowChar((i-6)*24, 48, a1[i]+48,OLED_8X16);}//第3行显示
	}}; break;//
		
				
				case 4: aj=0;if(x!=0&&x!=3&&x!=6){a1[x]=a1[x-1];a1[x-1]=' '-48;x=x-1;for(i=0;i<9;i++){//地图显示
			if(i<3){OLED_ShowChar(i*24, 0, a1[i]+48,OLED_8X16);}//第一行显示
		if(i>2&&i<6){OLED_ShowChar((i-3)*24, 24, a1[i]+48,OLED_8X16);}//第二行显示
		if(i>5){OLED_ShowChar((i-6)*24, 48, a1[i]+48,OLED_8X16);}//第3行显示
	}}; break;//
				case 5:aj=0; OLED_Clear();OLED_Update();return 0; break;//退出//
				case 6: aj=0; 	if(x+3<9){a1[x]=a1[x+3];a1[x+3]=' '-48;x=x+3;for(i=0;i<9;i++){//地图显示
			if(i<3){OLED_ShowChar(i*24, 0, a1[i]+48,OLED_8X16);}//第一行显示
		if(i>2&&i<6){OLED_ShowChar((i-3)*24, 24, a1[i]+48,OLED_8X16);}//第二行显示
		if(i>5){OLED_ShowChar((i-6)*24, 48, a1[i]+48,OLED_8X16);}//第3行显示
	}}; break;//
				default: aj=0;break;
			}
		
	if(aj){	
	for(i=0;i<8;i++){//胜利判断
		if(a1[i]!=i+1){ break;}
		if(i==7){OLED_ShowChinese(80,24, "胜利");}
		}
	}
	}                                                                                                                  
	
}


//五子棋



int wzq()
{
	uint8_t x1=28,y1=28,c=0,qpx=4,qpy=4,sl=1;
	char qpsz[9][9]={0};//棋盘数组

	uint8_t x=0,y=0,qi=0,i=0,j=0,pj=0,msi=0,ms=0,kzq=1,zdpp=0;
	
	/*OLED初始化*/
//	OLED_Init();
//	anjian_Init();
OLED_Clear();	
OLED_ShowChinese(0,0, "单机");
OLED_ShowChinese(0,16, "联机");
OLED_ReverseArea(0, msi*16, 128, 16);
	
	
	while(1){//二级菜单
		if(ms!=0){break;}
		OLED_Update();
	
	
			switch(aj){
				case 1: aj=0;if(msi>0){OLED_ReverseArea(0, msi*16, 128, 16);msi--;OLED_ReverseArea(0, msi*16, 128, 16);}; break;
				//case 2: ;break;
				case 3: 
					aj=0;
								if(msi==0){ms=1;}
								if(msi==1){ms=2;}
								break;
									
				case 5:aj=0; return 0;break;
				case 6:aj=0; if(msi<3){OLED_ReverseArea(0, msi*16, 128, 16);msi++;OLED_ReverseArea(0, msi*16, 128, 16);}break;
				//case 1: ; break;
				default: aj=0;break;
			}
	
	}
	
	OLED_Clear();	

	
	OLED_DrawLine(7, 0, 7, 64);
	OLED_DrawLine(14, 0, 14, 64);
	OLED_DrawLine(21, 0, 21, 64);
	OLED_DrawLine(28, 0, 28, 64);
	OLED_DrawLine(35, 0, 35, 64);
	OLED_DrawLine(42, 0, 42, 64);
	OLED_DrawLine(49, 0, 49, 64);
	OLED_DrawLine(56, 0, 56, 64);
	
	OLED_DrawLine(0, 7, 64, 7);
	OLED_DrawLine(0, 14, 64, 14);
	OLED_DrawLine(0, 21, 64, 21);
	OLED_DrawLine(0, 28, 64, 28);
	OLED_DrawLine(0, 35, 64, 35);
	OLED_DrawLine(0, 42, 64, 42);
	OLED_DrawLine(0, 49, 64, 49);
	OLED_DrawLine(0, 56, 64, 56);
	OLED_ShowImage(x1+1, y1+1, 5, 5,gb);
	OLED_Update();
	
	if(ms==1){
   while(1){
  	
		 	switch(aj){
				case 1: aj=0;if(y1>0){OLED_ClearArea(x1+1, y1+1, 5, 5);
								if(qpsz[y1/7][x1/7]==1){OLED_ShowImage(x1+1, y1+1, 5, 5,bq);}////如果本格有棋子就还原它
								if(qpsz[y1/7][x1/7]==2){OLED_ShowImage(x1+1, y1+1, 5, 5,xq);}//
								y1-=7;OLED_ShowImage(x1+1, y1+1, 5, 5,gb);}; break;
				
				case 2: aj=0;if(x1<56){OLED_ClearArea(x1+1, y1+1, 5, 5);
								if(qpsz[y1/7][x1/7]==1){OLED_ShowImage(x1+1, y1+1, 5, 5,bq);}//如果本格有棋子就还原它
								if(qpsz[y1/7][x1/7]==2){OLED_ShowImage(x1+1, y1+1, 5, 5,xq);}//
								x1+=7;OLED_ShowImage(x1+1, y1+1, 5, 5,gb);}; break;
				
								
								case 3: aj=0;if(qpsz[y1/7][x1/7]==0){if(c==0){qpsz[y1/7][x1/7]=1;OLED_ShowImage(x1+1, y1+1, 5, 5,bq);}//
													else{qpsz[y1/7][x1/7]=2;OLED_ShowImage(x1+1, y1+1, 5, 5,xq);}//下棋逻辑
								
												///胜利判断逻辑
													for(char i=1;i<5;i++){													
															if((y1/7+i<8)&&(qpsz[y1/7+i][x1/7]==qpsz[y1/7][x1/7])){sl++;}////y轴下限判断
															if((y1/7-i>=0)&&(qpsz[y1/7-i][x1/7]==qpsz[y1/7][x1/7])){sl++;}////y轴上限判断
															if(i>=4&&sl<5){sl=1;}
													}
													
													for(char i=1;i<5;i++){													
															if((x1/7+i<8)&&(qpsz[y1/7][x1/7+i]==qpsz[y1/7][x1/7])){sl++;}////x轴下限判断
															if((x1/7-i>=0)&&(qpsz[y1/7][x1/7-i]==qpsz[y1/7][x1/7])){sl++;}////x轴上限判断	
															if(i>=4&&sl<5){sl=1;}
													}
													
													for(char i=1;i<5;i++){	//这里的数组逻辑可能理解反了，但由于棋盘对称功能仍然有效												
															if((y1/7+i<8)&&(x1/7+i<8)&&(qpsz[y1/7+i][x1/7+i]==qpsz[y1/7][x1/7])){sl++;}////斜轴\下限判断
															if((y1/7-i<8)&&(x1/7-i<8)&&(qpsz[y1/7-i][x1/7-i]==qpsz[y1/7][x1/7])){sl++;}////斜轴\上限判断
															if(i>=4&&sl<5){sl=1;}
													}
													
													for(char i=1;i<5;i++){													
															if((y1/7-i<8)&&(x1/7+i<8)&&(qpsz[y1/7-i][x1/7+i]==qpsz[y1/7][x1/7])){sl++;}////斜轴/下限判断
															if((y1/7+i<8)&&(x1/7-i>=0)&&(qpsz[y1/7+i][x1/7-i]==qpsz[y1/7][x1/7])){sl++;}////斜轴/上限判断	
															if(i>=4&&sl<5){sl=1;}
													}
											if(sl>=5){OLED_ShowChinese(80,0, "玩家");OLED_ShowNum(80, 17, c+1, 1, OLED_8X16);OLED_ShowChinese(80,40, "胜利");}
												sl=1;
											if(c==0){c=1;}else{c=0;}//切换控制权
											}; break;
								
								
				case 4: aj=0;if(x1>0){OLED_ClearArea(x1+1, y1+1, 5, 5);
								if(qpsz[y1/7][x1/7]==1){OLED_ShowImage(x1+1, y1+1, 5, 5,bq);}////如果本格有棋子就还原它
								if(qpsz[y1/7][x1/7]==2){OLED_ShowImage(x1+1, y1+1, 5, 5,xq);}//
								x1-=7;OLED_ShowImage(x1+1, y1+1, 5, 5,gb);}; break;		
				
				case 5:aj=0; return 0;break;
								
				case 6:aj=0;if(y1<56){OLED_ClearArea(x1+1, y1+1, 5, 5);
								if(qpsz[y1/7][x1/7]==1){OLED_ShowImage(x1+1, y1+1, 5, 5,bq);}////如果本格有棋子就还原它
								if(qpsz[y1/7][x1/7]==2){OLED_ShowImage(x1+1, y1+1, 5, 5,xq);}//
								y1+=7;OLED_ShowImage(x1+1, y1+1, 5, 5,gb);}; break;
				
				default: aj=0;break;
			}
				 
		 OLED_Update();
		}
	}
	
	if(msi==2){
	
	}
}






//菜单
void caidan(){
typedef struct {
	uint8_t sy;
	char *mz;
	int (*hs)();
} rj;

 rj rjz[12] = {
        {1, "设置", shezhi}, {2, "聊天室", lts}, {3, "射击游戏", sjhs}, {4, "三子棋", szq},
        {5, "数字华容道",  hrd}, {6, "五子棋", wzq}, {7, "程序", kon}, {8, "程序", kon},
        {9, "程序", kon}, {10, "程序", kon}, {11, "程序", kon}, {12, "程序", kon}
    };
    
    uint8_t i = 0, j = 0, gb = 0;
		
		aj=0;


    while(1) {
			
        
        switch(aj) {
            case 1: 
								aj=0;
                if(gb > 0) {
                    gb -= 16;
                } else {
                    gb = 48;
                    if(i > 0) { i--; } else { i = 2; }
                }
                break;
                
						case 2: 
								aj=0;
								if(i<2){i++;}else{i=0;}
								break;
						
            case 3: 
								aj=0;
                OLED_Clear();
                OLED_Update();
                rjz[i*4 + gb/16].hs();  
                break;
						
						case 4: 
								aj=0;
								if(i>0){i--;}else{i=2;}
								break;
                
            case 6: 
								aj=0;
                if(gb < 48) {
                    gb +=16;
                } else {
                    gb=0;
                    if(i < 2) { i++;} else { i=0;}
                }
                break;
                
            default: 
							aj=0;
                break;
        }
								OLED_Clear();
                OLED_ShowNum(0, 0, rjz[i*4].sy, 2, OLED_8X16);
                OLED_ShowChinese(16, 0, rjz[i*4].mz);
                
                OLED_ShowNum(0, 16, rjz[i*4+1].sy, 2, OLED_8X16);
                OLED_ShowChinese(16, 16, rjz[i*4+1].mz);
                
                OLED_ShowNum(0, 32, rjz[i*4+2].sy, 2, OLED_8X16);
                OLED_ShowChinese(16, 32, rjz[i*4+2].mz);
                
                OLED_ShowNum(0, 48, rjz[i*4+3].sy, 2, OLED_8X16);
                OLED_ShowChinese(16, 48, rjz[i*4+3].mz);
                
                OLED_ReverseArea(0, gb, 128, 16);
        OLED_Update(); 
    }	

}

//TIM2的中断函数
void TIM2_IRQHandler(void){
if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET){//判断TIM中断标志位
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);//清除TIM的中断标志位，以防止重复进入中断卡死
	tim2_i++;
	

//	if(aj_a||aj_b){//按键触发,10次100ms,按下松开都消抖100sm,aj_a双开消抖，aj_b按下消抖，aj_c计时
//		aj_c++;
//		if(aj_a==0&&aj_c>=10){aj_c=0;aj=aj_b;aj_b=0;aj_a=1;}//按下消抖
//		if(aj_a==1&&aj_c>=10){aj_c=0;aj_a=0;}//松开消抖
//	}

	
	if(aj_a||aj_b){//按键触发,10次100ms,按下松开都消抖100sm,aj_a双开消抖，aj_b按下消抖，aj_c计时
		aj_c++;
		if(aj_a==0&&aj_c>=3){
				switch(aj_b){
					case 1: if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)==0){aj=aj_b;}aj_a=1;aj_c=0;aj_b=0; break;
					case 2: if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)==0){aj=aj_b;}aj_a=1;aj_c=0;aj_b=0;;break;
					case 3: if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)==0){aj=aj_b;}aj_a=1;aj_c=0;aj_b=0;break;
					case 4: if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)==0){aj=aj_b;}aj_a=1;aj_c=0;aj_b=0; break;				
					case 5:	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)==0){aj=aj_b;}aj_a=1;aj_c=0;aj_b=0;break;
					case 6: if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)==0){aj=aj_b;}aj_a=1;aj_c=0;aj_b=0;break;
				
				default: break;
			}
			}	
		if(aj_a==1&&aj_c>=3){aj_c=0;aj_a=0;}//松开消抖
	}

//	
	if(tim2_i>=100){//每次10ms，100次==1秒
		tim2_i=0;
			
			i++;
			if(i>9){i=0;}//遍历随机数组
		}
	
		
		
	}
}

////按键中断服务函数
//void EXTI0_IRQHandler(void)
//{
//    // 检查中断标志位
//    if(EXTI_GetITStatus(EXTI_Line0) != RESET)
//    {
//			// 必须清除中断挂起标志
//        EXTI_ClearITPendingBit(EXTI_Line0);
//			
//			//中断处理
//	//	if(aj_a==0){
//			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)==0){
//				aj_b=1;			
//			}
//			
//      if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)==0){
//				aj_b=2;			
//			}
//			
//			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)==0){
//				aj_b=3;			
//			}
//						
//			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)==0){
//				aj_b=4;			
//			}
//						
//			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)==0){
//				aj_b=5;			
//			}
//						
//			if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)==0){
//				aj_b=6;			
//			}
//	//	} 
//        
//    }
//}
// PA1
void EXTI1_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line1) == SET)
    {
        // 按键1动作
			aj_b=1;
        EXTI_ClearITPendingBit(EXTI_Line1);
    }
}

// PA2
void EXTI2_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line2) == SET)
    {
        // 按键2动作
				aj_b=2;
        EXTI_ClearITPendingBit(EXTI_Line2);
    }
}

// PA3
void EXTI3_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line3) == SET)
    {
        // 按键3动作
				aj_b=3;
        EXTI_ClearITPendingBit(EXTI_Line3);
    }
}

// PA4
void EXTI4_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line4) == SET)
    {
        // 按键4动作
				aj_b=4;
        EXTI_ClearITPendingBit(EXTI_Line4);
    }
}

// PA5、PA6 共用
void EXTI9_5_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line5) == SET)
    {
        // 按键5动作
				aj_b=5;
        EXTI_ClearITPendingBit(EXTI_Line5);
    }

    if(EXTI_GetITStatus(EXTI_Line6) == SET)
    {
        // 按键6动作
				aj_b=6;
        EXTI_ClearITPendingBit(EXTI_Line6);
    }
}

