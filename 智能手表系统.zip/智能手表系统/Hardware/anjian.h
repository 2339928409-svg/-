#ifndef __anjian_h
#define __anjian_h

#include <stdint.h>
void anjian_Init(void);
//uint8_t anjian(void);

#endif
