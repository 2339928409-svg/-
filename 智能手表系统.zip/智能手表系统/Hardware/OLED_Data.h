#ifndef __OLED_DATA_H
#define __OLED_DATA_H

#include <stdint.h>

/*中文字符字节宽度*/
#define OLED_CHN_CHAR_WIDTH			3		//UTF-8编码格式给3，GB2312编码格式给2

/*字模基本单元*/
typedef struct 
{
	char Index[OLED_CHN_CHAR_WIDTH + 1];	//汉字索引
	uint8_t Data[32];						//字模数据
} ChineseCell_t;

/*ASCII字模数据声明*/
extern const uint8_t OLED_F8x16[][16];
extern const uint8_t OLED_F6x8[][6];

/*汉字字模数据声明*/
extern const ChineseCell_t OLED_CF16x16[];

/*图像数据声明*/
extern const uint8_t Diode[];
extern const uint8_t aixing[];//爱心
extern const uint8_t jc[];//教程图片
extern const uint8_t ren[];//小人/
extern const uint8_t qipan[];//井字棋盘
extern const uint8_t sanjiao[];//三角棋
extern const uint8_t fang[];//方棋
extern const uint8_t gb[];//光标5*5
extern const uint8_t qiang[];//枪
extern const uint8_t fk[];//目标方块16*16
extern const uint8_t sjyx[];//射击游戏图片128*64
extern const uint8_t xq[];//X棋子
extern const uint8_t bq[];//白棋子
/*按照上面的格式，在这个位置加入新的图像数据声明*/
//...

#endif


/*****************江协科技|版权所有****************/
/*****************jiangxiekeji.com*****************/
