#include "stm32f10x.h"   
#include <string.h>
#include <stdio.h>

#define uchar unsigned char

volatile uint8_t rx_complete_flag = 0;
volatile char esp_rx_buf[256]={0};
volatile uint8_t esp_rx_index = 0;

void ESP8266_UART_Init(void) {
    // ���� USART1 ʱ�ӣ�APB2��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    // ���� GPIOA ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitTypeDef GPIO_InitStruct;
    
    // PA9 ��Ϊ TX���������������
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    // PA10 ��Ϊ RX���������룩
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    // USART1 ���ã������� 115200, 8N1��
    USART_InitTypeDef USART_InitStruct;
    USART_InitStruct.USART_BaudRate = 115200;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &USART_InitStruct);

    USART_Cmd(USART1, ENABLE);
		
		// ʹ�� USART1 �����ж�
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    
    // �����ж����ȼ�������ʹ�� NVIC��
    NVIC_InitTypeDef NVIC_InitStruct;
    NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
    
    USART_Cmd(USART1, ENABLE);
}

void ESP8266_SendCmd(char *cmd) {
    while(*cmd) {
        while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
        USART_SendData(USART1, *cmd++);
    }
    // ���ͻس�����
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, '\r');
    while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    USART_SendData(USART1, '\n');
    while(USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);
}

void ESP8266_Cmd(char *cmd) {
    while(*cmd) {
        while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
        USART_SendData(USART1, *cmd++);
    }
  
}

//�����ж�
void USART1_IRQHandler(void) {
	
	
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        char c = USART_ReceiveData(USART1);
        // ��Ľ��մ����߼�...
						//��д����������ǰ����һ��������0
			if(esp_rx_index == 0){
				for( char i=0;i<255;i++){
					esp_rx_buf[i]=0;
					}	
			}
			
			
			
			if(c == '\n') {
            esp_rx_buf[esp_rx_index] = '\0';
            rx_complete_flag = 1;
            esp_rx_index = 0;
        }
       else if(esp_rx_index < sizeof(esp_rx_buf) - 1) {
            esp_rx_buf[esp_rx_index++] = c;
        }
        
    }
}