#ifndef __dsq_H
#define __dsq_H

void dsq_Init(void);

#endif
