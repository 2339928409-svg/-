#ifndef __wifi_H
#define __wifi_H
void wifi_kai();
void wifi_kai_fs(char *zfc);
void wifi_lian();
void wifi_lian_fs(char *zfc);
#endif

