#include "stm32f10x.h"                  // Device header
#include "Delay.h"

void fmq_Init(void){
RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//开启GPIOA组引脚的时钟
	GPIO_InitTypeDef GPIO_InitStructure;//声明用于配置引脚参数的结构体
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;//配置引脚
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;//配置该GPIO引脚组的0引脚
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;//配置该引脚工作频率为50hz
	GPIO_Init(GPIOA,&GPIO_InitStructure);//将配置好参数的引脚结构体传给GPIOA组	
}
 
void fmq_set1(void){
GPIO_SetBits(GPIOA,GPIO_Pin_0);
}
	
void fmq_set0(void){
GPIO_ResetBits(GPIOA,GPIO_Pin_0);
}

void fmq_qf(){
if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_0)==0){
GPIO_SetBits(GPIOA,GPIO_Pin_0);
}else{
GPIO_ResetBits(GPIOA,GPIO_Pin_0);
}
}

