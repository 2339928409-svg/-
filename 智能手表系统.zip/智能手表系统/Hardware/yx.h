#ifndef __yx_H
#define __yx_H
int sjhs(void);
int kon();
	int szq();
int hrd();
int wzq();
extern uint8_t i;

#endif

