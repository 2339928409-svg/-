#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "dsq.h" 
#include "UART.h" 
#include <string.h>


void wifi_kai(){

		ESP8266_Cmd("+++");
		Delay_ms(500);
	
		ESP8266_SendCmd("AT+RESTORE");
		Delay_ms(500);
		ESP8266_SendCmd("AT+RST");
		Delay_ms(1000);
	
	ESP8266_SendCmd("ATE0");
	Delay_ms(500);
	ESP8266_SendCmd("AT+CWMODE=2");
						
	Delay_ms(2000);
								 
	ESP8266_SendCmd("AT+CWSAP=\"esp8266_a\",\"1371308813\",1,4");
						
	Delay_ms(2000);
								 
	ESP8266_SendCmd("AT+CIPMUX=1");
						
	Delay_ms(2000);  // �ȴ�����
									 
	ESP8266_SendCmd("AT+CIPSERVER=1,8888");
						
	Delay_ms(2000);

}

void wifi_kai_fs(char *zfc){
	
						//" "ռ1�ֽڡ��������ָ���һ���Ƚϴ�Ĺ̶���С���ַ������Ȳ������ÿո����
	ESP8266_SendCmd("AT+CIPSEND=0,24");
	Delay_ms(1);
	ESP8266_Cmd(zfc);
	Delay_ms(1);
	for(char c=strlen(zfc);c<24;c++){							
	ESP8266_Cmd(" ");
	Delay_ms(1);							
	}
						
		
}

void wifi_lian(){
	
						ESP8266_Cmd("+++");
						Delay_ms(500);
						ESP8266_SendCmd("AT+RESTORE");
						Delay_ms(500);
						ESP8266_SendCmd("AT+RST");
						Delay_ms(1000);
						ESP8266_SendCmd("ATE0");
						Delay_ms(500);
						ESP8266_SendCmd("AT+CWMODE=1");												
						Delay_ms(1000);
									
						ESP8266_SendCmd("AT+CWJAP=\"esp8266_a\",\"1371308813\"");									
						Delay_ms(6000);//����6��
						
					  ESP8266_SendCmd("AT+CIPSTART=\"TCP\",\"192.168.4.1\",8888");
						Delay_ms(1000);

}

void wifi_lian_fs(char *zfc){
							ESP8266_SendCmd("AT+CIPMODE=1");//��͸��
							Delay_ms(50);
							ESP8266_SendCmd("AT+CIPSEND");//����͸��
							Delay_ms(50);
							ESP8266_Cmd(zfc);//����Ϣ
							Delay_ms(50);
							ESP8266_Cmd("+++");//�˳�͸��
							Delay_ms(50);
							ESP8266_SendCmd("AT+CIPMODE=0");//��͸��
							Delay_ms(50);

}