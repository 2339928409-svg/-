#ifndef __UART_H
#define __UART_H
void ESP8266_UART_Init(void);
void ESP8266_SendCmd(char *cmd);
void ESP8266_Cmd(char *cmd);

#endif

