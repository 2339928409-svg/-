#include "stm32f10x.h"
#include "Delay.h"

void anjian_Init(void)
{
    // 1. 开时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);     // 复用时钟必须开
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);   // GPIOA时钟

    // 2. 先配置GPIO为上拉输入
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;          // 上拉输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3
                                | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 3. 每个引脚单独映射到EXTI
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource1);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource2);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource3);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource4);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource5);
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource6);

    // 4. 配置EXTI
    EXTI_InitTypeDef EXTI_InitStruct;
    EXTI_InitStruct.EXTI_Line = EXTI_Line1 | EXTI_Line2 | EXTI_Line3
                               | EXTI_Line4 | EXTI_Line5 | EXTI_Line6;
    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;   // 下降沿
    EXTI_InitStruct.EXTI_LineCmd = ENABLE;                  // 必须加！
    EXTI_Init(&EXTI_InitStruct);

    // 5. NVIC 配置所有用到的中断
    NVIC_InitTypeDef NVIC_InitStruct;

    // PA1
    NVIC_InitStruct.NVIC_IRQChannel = EXTI1_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);

    // PA2
    NVIC_InitStruct.NVIC_IRQChannel = EXTI2_IRQn;
    NVIC_Init(&NVIC_InitStruct);

    // PA3
    NVIC_InitStruct.NVIC_IRQChannel = EXTI3_IRQn;
    NVIC_Init(&NVIC_InitStruct);

    // PA4
    NVIC_InitStruct.NVIC_IRQChannel = EXTI4_IRQn;
    NVIC_Init(&NVIC_InitStruct);

    // PA5、PA6
    NVIC_InitStruct.NVIC_IRQChannel = EXTI9_5_IRQn;
    NVIC_Init(&NVIC_InitStruct);
}

//void anjian_Init(void){
//	

//RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);     // 复用功能时钟

//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//开启GPIOA组引脚的时钟
//	
//		
//	GPIO_InitTypeDef GPIO_InitStructure;//声明用于配置引脚参数的结构体
//	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;//配置引脚,上拉输入，默认1
//	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_6|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;//配置该GPIO引脚组的0引脚
//	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_2MHz;//配置该引脚工作频率为50hz
//	GPIO_Init(GPIOA,&GPIO_InitStructure);//将配置好参数的引脚结构体传给GPIOA组
//	
//	//配置引脚的中断线
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource1|GPIO_PinSource2|GPIO_PinSource3|GPIO_PinSource4|GPIO_PinSource5|GPIO_PinSource6);

//	//配置 EXTI 中断线、触发方式
//	EXTI_InitTypeDef EXTI_InitStruct;

//EXTI_InitStruct.EXTI_Line = EXTI_Line0;//中断线
//EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;   // 中断模式（触发中断而不是事件）
//EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling; // 沿
//// 可选：Rising 上升沿 / Falling 下降沿

//EXTI_Init(&EXTI_InitStruct);

//	
////配置 NVIC 中断优先级	
//NVIC_InitTypeDef NVIC_InitStruct;

//NVIC_InitStruct.NVIC_IRQChannel = EXTI0_IRQn;
//NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;  // 抢占优先级
//NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;         // 子优先级
//NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;

//NVIC_Init(&NVIC_InitStruct);



//}

//uint8_t anjian(void){
//if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)==0){
//	Delay_ms(20);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)==0);
//	Delay_ms(20);
//	return 1;
//	}

//if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)==0){
//	Delay_ms(20);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)==0);
//	Delay_ms(20);
//	return 2;
//	}
//if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)==0){
//	Delay_ms(20);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)==0);
//	Delay_ms(20);
//	return 3;
//	}

//if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)==0){
//	Delay_ms(20);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4)==0);
//	Delay_ms(20);
//	return 4;
//	}
//if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)==0){
//	Delay_ms(20);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5)==0);
//	Delay_ms(20);
//	return 5;
//	}

//if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)==0){
//	Delay_ms(20);
//	while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)==0);
//	Delay_ms(20);
//	return 6;
//	}
//	return 0;	

//}

