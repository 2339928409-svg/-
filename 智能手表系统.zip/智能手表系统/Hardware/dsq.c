#include "stm32f10x.h"
void dsq_Init(void){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//使能APB1总线上的TIM2	
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_TimeBaseInitStruct.TIM_ClockDivision= TIM_CKD_DIV1;//设置时钟分频，_DIV1，_DIV2，_DIV4，1、2、4分频
	TIM_TimeBaseInitStruct.TIM_CounterMode= TIM_CounterMode_Up;//设置为计数器向上计数模式
	TIM_TimeBaseInitStruct.TIM_Period= 100-1;//计数/定时次数,这里计数100次，即100*1万微秒=0.01秒==10ms
	TIM_TimeBaseInitStruct.TIM_Prescaler= 7200-1;//自动重装，用来设每次的时间，定时频率为72mhz，这里对72M分频7200次，即72000000/7200=每次1万微秒
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter= 0;//预分频，重复计算器配置，这里不使用	
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStruct);
	
	//TIM_ClearITPendingBit(TIM2,TIM_IT_Update);//清除TIM的中断标志位,因为上面TIM的配置会把中断标志位置1，所以在这里清除
	TIM_ClearFlag(TIM2,TIM_FLAG_Update);//清除TIM的中断标志位,因为上面TIM的配置会把中断标志位置1，所以在这里清除
	
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);//更新中断道NVIC,_Update参数是更新中断
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//设置NVIC中断分组
	
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel=TIM2_IRQn;//指定中断通道
	NVIC_InitStruct.NVIC_IRQChannelCmd=ENABLE;//开启或关闭指定通道
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority=2;//配置抢占优先级
	NVIC_InitStruct.NVIC_IRQChannelSubPriority=2;//配置相应优先级
	NVIC_Init(&NVIC_InitStruct);
	
	TIM_Cmd(TIM2,ENABLE);//启动定时器
}

////TIM2的中断函数
//void TIM2_IRQHandler(void){
//if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET){//判断TIM中断标志位
//			TIM_ClearITPendingBit(TIM2,TIM_IT_Update);//清除TIM的中断标志位，以防止重复进入中断卡死
//	}
//}