#ifndef __fmq_H
#define __fmq_H
void fmq_Init(void);
void fmq_set0(void);
void fmq_set1(void);
void fmq_qf(void);
#endif