#include "stm32f10x.h"                  
#include "Delay.h"
#include "OLED.h"
#include "anjian.h"
#include "fmq.h"
#include "dsq.h" 
#include "yx.h"
#include "wifi.h"
#include "UART.h" 

#define uchar unsigned char

//��ʱ���жϰ���
int main(void)
{
	ESP8266_UART_Init();
	OLED_Init();
   anjian_Init();
	dsq_Init();
	
   while(1){
   caidan();
   
   
   }
}



